fetch('https://api.thecatapi.com/v1/images/search')
  .then(response => response.json())
  .then(data => {
    
    // 创建img元素
    let img = document.createElement('img');
    img.src = data[0].url;
    
    // 设置图片样式为全屏
    img.style.position = 'fixed';
    img.style.top = '50%';
    img.style.left = '50%'; 
    img.style.transform = 'translate(-50%, -50%)';
    img.style.width = '100vw';
    img.style.height = '100vh';
    img.style.objectFit = 'cover';
    
    // 添加img到body
    document.body.appendChild(img);
    
  })
  .catch(error => console.error('Error:', error));